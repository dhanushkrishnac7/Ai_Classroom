"use client"
import { useContext } from "react"
import { Badge } from "@/components/ui/badge"
import ClassCard from "./ClassCard"
import {fetchdata} from "../../layout"
function Ownedclasses() {
  const { dashboardResponse } = useContext(fetchdata);
    const colors = [
      "rgba(56, 142, 60)",    
      "rgba(0, 105, 92)",     
      "rgba(93, 64, 55)",
      "rgba(255, 112, 67)",   
      "rgba(69, 90, 100)",       
      "rgba(0, 137, 123)",    
      "rgba(46, 125, 50)", 
      "rgba(0, 121, 107)",     
      "rgba(21, 101, 192)",   
      "rgba(25, 118, 210)",    
      "rgba(66, 66, 66)",    
      "rgba(63, 81, 181)", 
];
  return (
    <div className="bg-gray-50 p-6">
      <div className="max-w-xl  space-y-8">
        <section>
          <div className="flex items-center gap-3 mb-6">
            <h2 className="text-2xl font-semibold text-gray-800">Teaching</h2>
            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
              {dashboardResponse?.ownedClassrooms?.length || 0} Classes
            </Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {dashboardResponse?.ownedClassrooms?.map((classItem,idx) => (
              <ClassCard
                key={classItem.id}
                classItem={{
                  title: classItem.classname,
                  instructor: "You",
                  avatar: classItem.classname[0]?.toUpperCase(),
                  color: colors[idx%colors.length],
                  id: classItem.id,
                  role: classItem.role,
                }}
              />
            ))}
          </div>
        </section>
      </div>
    </div>
  )
}

export default Ownedclasses
